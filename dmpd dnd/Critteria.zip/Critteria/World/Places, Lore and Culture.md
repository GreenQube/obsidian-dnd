This section is used for a comprehensive place to write down places in the world, lore and culture important things

# **Ar’ila**

An empire which has a ruler called the **Critterian Emperor.** A long standing tradition that Criteria ought to have a ruler and a representative of the lands stands. In the great city of **Anuman** resides the emperor. The current emperor is a renown scholar and a man of great renown, Sir Roland Galantys, (an Indian Peafowl) which has been ruling for quite some time, nearing an old age. The next Criterion Empire is chosen by the current ones wishes, usually chosen in on of the old ways, weather himself choosing an heir or a respected connected animal chosen by the people. The current emperor may choose in which ways he will be succeeded, but he must abide by the wishes of the other great nations that make up this empire.

_Nations that make up the empire_:

- **[[G'nawentus]]** (rodentfolk + allied land critters) *
- **Aviora (birdfolk)**
- **Sculum (reptilefolk)**
- **Palak (amphibianfolk)**
- **_[[Vulpera]]_ (foxfolk, weaselfolk, racoonfolk, etc)***
- **Locathia (sea fishfolk) + Nessia (land fishfolk)**
- **Bemur** (lemursfolk + batfolk + others)
- **Voseche (the grand capital with lots, boiling pot of culture)**

# Vuplera

Vulpera is known for its cunning citizens as well as their adaptability and cultural fondness of athletic ability and political schemeing. Of its many towns and communities 2 major cities stand out. _**Maresh**_ (city of badgers, otters and the like) and **Krata** (the capital city of mostly foxes, weasels, ferrets). *Krata, and by extension *_Vulpera_ has been ruled by the _Ruza dinasty_ a family of foxfolk. At the head of the family, the ruler is Doran Ru’za a grayfox of noteriety.

# G'nawentus
### Z’hir
#### **Place**

Grad veverica, letecih veverica, hrcka, guinnea pigs uglavnom. Kuce/gradjevine su kombinacija uzemljenih kuca i drvo-kuca koje su kucice u drvetu ili kucice na drvetu bukvalno zamisli kucice za veverice samo skalirane na vertikalu. U njemu prate religiju Zira i Majka Sume Wildmother). Vodi je mayor Major Veverkic(ima velike brkove). Imaju simbiozu s lokalnim “VECNIM MOLJCEM” ([https://www.5esrd.com/database/creature/corpselight-moth/](https://www.5esrd.com/database/creature/corpselight-moth/)) zvan **Sith**. Moljac preko dana skuplja necrotic energiju umrlih biljaka/stvari/otpatka i u sumraku pojede posebno cvece Dramino Svetlo (light flower) koje convertuje necrotic energy u njemu a on onda rasprsi preradjenu energiju u lokalnu floru i faunu. Zive u simbiozi tako sto ljudi godinama sade posede ovih svetlosnih cvetova.

Worshipuju Sith-a i mole mu se videvsi ga kao divine stvorenje povezano za Majku prirodu i zir. Polen koji Sith rasprstava po gradu/selu tera da bilo sta sto se na tom podrucju uzrasta da raste puno. Zato su cvece, drvece i ostalo bilje supersizeovano i ljudi zive dobro.

Main city:

Following things are of note

**Tuzna Puz** - Taverna lokalna gde idu ljudi da odmore, piju, zebavaju se, dosta prazna u zadnje vreme…

**Coughing Reed(Travka koja kaslje**) - apoteka s razlicitim potions, pomade, sokove mirisljavo bice, travke i prahove za magicne napitke, drzi ga Daren (weasel koji kaslje i smeje se kasljavo)

Potions for sale:

- Potion of Necrotic resistance 1hr (50g)
- Potion of Plant Speak 1d4hr (75g)
- Lotion of Jump (quad jump) 1hr (50g)
- Lotion of Hardening (1d12 temp hp) (50gp)
- Potion of Lesser Hp (40g)

**Drvo izuma(visoko drvo u kojem zivi Trina inzinjer)** - Visoko zanimljivo drvo u kom eksperimentise i radi Trina. Ima par itema koje pravi trenutno

- Squirrel glides of flying (1d6 to fail every turn)
- Unstable potion of tarp shaking (casts entangle in the place where it is opened)
- Gloves of telekinesis (can make ranged attacks with fists)
- [https://dnd5e.wikidot.com/wondrous-items:finders-goggles](https://dnd5e.wikidot.com/wondrous-items:finders-goggles)

**Slepa Basta** - kuca stare bradate krtice **Gorble** koja pravi cajeve i zove ljude na lep provod i druzenje. Generalno ljudi idu kod njega ali su prestali od kad je pocelo svo sranje da se desava u selu. U njoj zivi **Gorble**, stara krtica koja ne vidi skoro uopste ali prepoznaje odredjene stvari, mirise prolaze i potencijalne buducnosti. Moze i lore dropovati za macke i vecnost.

A**lmond shells -** sumast, poljanast i mocvarast deo gde ljuspe rastu po svemu, stvrdnjavaju se kao barnickles i ubrzo stope osobu s drvecem, kao paraziti, rade za drvo i skupljaju nutrijente a drvo raste, ili biljka. U mocvarici se mogu naci neke velike bogomoljke ([https://www.5esrd.com/database/creature/mantis-giant/](https://www.5esrd.com/database/creature/mantis-giant/)). Dalje u sumi, ka istoku, **je kucica S’nar**a. Sto severnije se ide dolazi se do napustene vile u kojoj je Ethernal Moth

Rosepathed Mansion - overgrown mansion, two story, small by comparison, in the upper floor of the mansion, in the main reception hallway there is the moth lair. To get to there you have to go through winding side paths, since the main stair area is destroyed.

#### **NPCS**

Major Veverkic - major grada, boushy brkvoi s texan brkovima, ne zna sta se bas desava ali moze da generanlo isprica o glasniku sume

Gospodja Verica (Dabar) - personal assistent Majoru Veverkicu

**Trina** - engineer squirrel koji eksperimentise s razlicitm spravama. Napravili leteca krila (kao za vevericu), smokebomb, pored njih se nalazilo jedno telo, generalno happy go lucky osoba, necak gospodina Veverkica. Sanja o tome da ode u veliki grad i bude nesto. Pravi eksperimentalne stvari i veoma brz i aktivan. Bratanac je Majora Veverkica. Zivi u Drvu izuma

S’nar (hrcak) - druid boginje Sume, i onaj koji komunicira s **Sith** koliko se moze komunicirati. Generalno povucen i ne voli mnogo da se propagira kroz drustvo, keeps to himself. Introvertan ali generalno prijatan s ljudima ako pricas s njim. Smrdi. Hteo je da s bandom napravi dogovor da im da radiant cvece, i cak i baby moth creature a zauzvrat da im se pridruzi, medjutim zajebao se i nije ocekivao da ce Sith da bude toliko protective.

**Daren (weasel)** - weasel apothacary drzi prodavnicu apotekarnicu (Coughing Reed), sivkasto beo smeje se eheeee(weasuje) kad prica. Prodaje potions, pomade, sokove, bilo sta tecno i otrove. Takodje jake mirise ispusta, i smrdi mu kucica

**Gorble (stara mudra krtica)** - Generalno zamajena malo alchajmecarska krtica koja vidi stvari koje drugi ne vide (tipa prepozna bedz macke i zna za macke), ili prepozna da je neko vezan za odredjenu vrstu… Bas prijatan, malo Irohlike lik koji voli da prica i da se osecaju ljudi prijatno. Pravi custom cajeve koji su lepi i mozda buffuju, ili ciste glavobolju.
